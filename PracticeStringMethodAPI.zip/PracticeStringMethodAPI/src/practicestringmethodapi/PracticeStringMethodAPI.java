/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicestringmethodapi;

/**
 *
 * @author dehkhoda_abbas
 */
public class PracticeStringMethodAPI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cde = "cde";
        String c = "abc".substring(2,3);
        String d = cde.substring(1, 2);
        
        System.out.println("d ="+d+ "  c= "+c);
        String eMail = makeEmail("Lisa" , "Smith");
        System.out.println(eMail);
        
        
        System.out.println(getPos("This is a Tesing",'T'));
        System.out.println(doTheJob("This is a Tesing"));
        
        String xx = "This is a Testing";
        for (int i = 0; i < xx.length(); i++)
        {
          
          String str = doTheJob(xx);
          System.out.println(str);
          xx = str;
           System.out.println(getPos("This is a Testing","Testing"));
        }
        System.out.println(doReplace ("This is a Test Test Test","Test","Exam"));
        
    }
    public static String doTheJob(String x)
    {
        char ch = x.charAt(0);
        String sub = x.substring(1);
        String newStr = sub+ch;
        return newStr;
        
    }
    
    public static int getPos(String x, char ch)
    {
       return x.indexOf(ch);
        
    }
    public static int getPos(String x, String xx)
    {
        
        return x.indexOf(xx);
    }
    public static String makeEmail(String f , String last)
    {
        
     return last+"_"+f+"@student.smc.edu";   
    }
    public static String doReplace (String orig, String old, String newStr)
    {
        
        return orig.replaceAll(old, newStr);
        
    }
    }
   


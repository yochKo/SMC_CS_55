
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dehkhoda_abbas
 */
public class DoPractice 
{  
    public static void main(String [] args)
    {
        
   String str     = throwDice(1000);
    System.out.println(str);
        
        /*
       for(int i=0 ; i < 20; i++)
       {
           int r = (int)(Math.random()*(365-25+1)) + 25;
           System.out.println("====>>"+r);
       }
*/
    System.exit(0);
    
    }
    public static String throwDice(int nTime)
    {   int n1,n2,n3,n4,n5,n6;
         n1=n2=n3=n4=n5=n6= 0;
        for(int i=0 ; i < nTime ; i++)
        {
            int dice = (int)(Math.random()*(6-1+1))+ 1;
            switch(dice)
            {
                case 1 : n1++; break;
                case 2 : n2++; break;
                case 3 : n3++; break;
                case 4 : n4++; break;
                case 5 : n5++; break;
                case 6 : n6++; break;
                default : ;
               
            }
                
            
        }
        String out ="Dice was thrown "+nTime+"\n";
        out+="Occurences of 1's : "+n1+"\n";
        out+="Occurences of 2's : "+n2+"\n";
        out+="Occurences of 3's : "+n3+"\n";
        out+="Occurences of 4's : "+n4+"\n";
        out+="Occurences of 5's : "+n5+"\n";
        out+="Occurences of 6's : "+n6+"\n";
        JOptionPane.showMessageDialog(null,out);
       return out; 
    }
}


import java.util.Scanner;



/**
 *
 * @author dehkhoda_abbas
 */
public class IODemo 
{
    public static void main(String [] args)
    {  
        int x; char xx;double f; boolean g;
        x = 65;
        xx = 'A';f = 18.7654;g = 45 > 56;
        System.out.printf("xx=%c, x=%d, f=%.6f\ng=%b\n", xx,x,f,g);
        String out = String.format("xx=%c, x=%d, f=%.6f\ng=%b\n", xx,x,f,g);
         System.out.println(out);
        
        
        
        Scanner input = new Scanner(System.in);
        System.out.print( "What is your:");
        String name = input.nextLine();
        System.out.println(name + " your name has "
                +name.length()+ " Characters");
        for(int i= 0 ; i < name.length(); i++)
        {
           System.out.println( name.charAt(i));
        }
        
        int pos = name.indexOf('S');
        if(pos != -1)
        {
            System.out.println("S find at loaction :"+pos);
        }
        else
        {
           System.out.println( "Not found...");
        }
        
        
        
       // showIO();
        System.exit(0);
    }
    
    public void hello()
    {
        System.out.println( "Hi.....");
    }
    public static void showDoWhileEndingTrueFalse() 
    {
        Scanner input = new Scanner(System.in);
        boolean resp;
        do
        {
            
            
            
         System.out.println("Enter (true/false):");
         resp = input.nextBoolean();
        }while(resp);
        
    }
    
    
    public static void showDoWhileEndingWithString()
    {
        Scanner input = new Scanner(System.in);
        String resp;
        do
        {
            
            
            
         System.out.println("Enter (Yes/No):");
         resp = input.next();
        }while(resp.equalsIgnoreCase("yes"));
    }
    
    
    
    public static void showDoWhileEndingWithCharacter()
    {
        Scanner input = new Scanner(System.in);
        char resp;
        do
        {
            
            
            
         System.out.println("Enter (Y/N)");
         resp = input.next().charAt(0);
        }while(resp=='Y');
        
        
    }
    
    public static void showIO()
    {
        Scanner input = new Scanner(System.in);
        
        System.out.print("enter an Integer:");
        int a = input.nextInt();
        System.out.println("you just entered:"+a);
        System.out.print("enter a char:");
        input.nextLine();
        char ch = input.nextLine().charAt(0);
        System.out.println("yo just entered:"+ch);
        
        System.out.print("enter a  double:");
        double d = input.nextDouble();
        System.out.println("you just entered:"+d);
        System.out.print("enter a  true/false:");
        
        boolean b = input.nextBoolean();
         System.out.println("you just entered:"+b);
        
    }
    
    
    
    
    
}

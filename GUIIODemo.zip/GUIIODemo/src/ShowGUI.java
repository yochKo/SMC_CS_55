
import java.awt.Color;
import java.awt.Font;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dehkhoda_abbas
 */
public class ShowGUI 
{
    public static void main(String [] args)
    {
        int n1 = MyIO.getInt("Enter an Integer");
        int n2 = MyIO.getInt("Enter Second Integer");
        MyIO.display("Total is "+(n1+n2));
       
        /*
        String strNum = JOptionPane.showInputDialog
        ("Enter an Integer");
        int n1 = Integer.parseInt(strNum);
        strNum = JOptionPane.showInputDialog
        ("Enter an Intege");
        int n2 = Integer.parseInt(strNum);
        JOptionPane.showMessageDialog(null, "Total is "+(n1+n2));
        display("Total is "+(n1+n2));
        display("Total is "+(n1+n2),Color.WHITE,Color.BLACK,25);
       */
        System.exit(0);
    }
    
    public static void display(String s)
    {
        JTextArea jt = new JTextArea(20,15);
        jt.setBackground(Color.YELLOW);
        jt.setForeground(Color.BLUE);
        
        Font f = new Font("times new roman",Font.BOLD+Font.ITALIC,32);
        jt.setFont(f);
        jt.setText(s);
        JScrollPane sr = new JScrollPane(jt);
        JOptionPane.showMessageDialog(null,sr);
        
    }
    public static void display(String s,Color fg,Color bc,int size)
    {
        JTextArea jt = new JTextArea(20,15);
        jt.setBackground(bc);
        jt.setForeground(fg);
        
        Font f = new Font("times new roman",Font.BOLD+Font.ITALIC,size);
        jt.setFont(f);
        jt.setText(s);
        JScrollPane sr = new JScrollPane(jt);
        JOptionPane.showMessageDialog(null,sr);
        
    }
    
}
class MyIO
{
    
    private MyIO()
    {
        
    }
    public static int getInt(String s)
    {
        int n1=0; String strNum="";
        boolean okay = false;
        
        while( ! okay)
        {
            try
            {
                
                strNum = JOptionPane.showInputDialog("Enter an Intege");
                n1 = Integer.parseInt(strNum);
                okay = true;
                
            }
            catch (Exception e)
            {
                JOptionPane.showMessageDialog(null,strNum + " is not Integer\nTry again");
            }
            
            
        }
        
       return n1; 
        
    }
    public static void display(String s)
    {
        JTextArea jt = new JTextArea(20,15);
        jt.setBackground(Color.YELLOW);
        jt.setForeground(Color.BLUE);
        
        Font f = new Font("times new roman",Font.BOLD+Font.ITALIC,32);
        jt.setFont(f);
        jt.setText(s);
        JScrollPane sr = new JScrollPane(jt);
        JOptionPane.showMessageDialog(null,sr);
        
    }
    public static void display(String s,Color fg,Color bc,int size)
    {
        JTextArea jt = new JTextArea(20,15);
        jt.setBackground(bc);
        jt.setForeground(fg);
        
        Font f = new Font("times new roman",Font.BOLD+Font.ITALIC,size);
        jt.setFont(f);
        jt.setText(s);
        JScrollPane sr = new JScrollPane(jt);
        JOptionPane.showMessageDialog(null,sr);
        
    }
    
    
    
}